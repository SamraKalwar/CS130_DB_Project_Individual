using Microsoft.AspNetCore.Mvc;
using WebApplication1.Data;
using WebApplication1.Models;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MaintenanceController : ControllerBase
    {
        private readonly ResortDbContext _context;
        public MaintenanceController(ResortDbContext context) => _context = context;

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Maintenance>>> Get() => await _context.Maintenance.ToListAsync();

        [HttpPost]
        public async Task<ActionResult<Maintenance>> Post(Maintenance maintenance)
        {
            _context.Maintenance.Add(maintenance);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = maintenance.MaintenanceID }, maintenance);
        }
    }
}
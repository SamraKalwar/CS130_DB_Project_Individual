using Microsoft.AspNetCore.Mvc;
using WebApplication1.Data;
using WebApplication1.Models;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SkatingSessionController : ControllerBase
    {
        private readonly ResortDbContext _context;
        public SkatingSessionController(ResortDbContext context) => _context = context;

        [HttpGet]
        public async Task<ActionResult<IEnumerable<SkatingSession>>> Get() => await _context.SkatingSessions.ToListAsync();

        [HttpPost]
        public async Task<ActionResult<SkatingSession>> Post(SkatingSession session)
        {
            _context.SkatingSessions.Add(session);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = session.SessionID }, session);
        }
    }
}
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Data;
using WebApplication1.Models;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TouristController : ControllerBase
    {
        private readonly ResortDbContext _context;
        public TouristController(ResortDbContext context) => _context = context;

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Tourist>>> Get() => await _context.Tourists.ToListAsync();

        [HttpPost]
        public async Task<ActionResult<Tourist>> Post(Tourist tourist)
        {
            _context.Tourists.Add(tourist);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = tourist.TouristID }, tourist);
        }
    }
}
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Data;
using WebApplication1.Models;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EquipmentController : ControllerBase
    {
        private readonly ResortDbContext _context;
        public EquipmentController(ResortDbContext context) => _context = context;

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Equipment>>> Get() => await _context.Equipment.ToListAsync();

        [HttpPost]
        public async Task<ActionResult<Equipment>> Post(Equipment equipment)
        {
            _context.Equipment.Add(equipment);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = equipment.EquipmentID }, equipment);
        }
    }
}
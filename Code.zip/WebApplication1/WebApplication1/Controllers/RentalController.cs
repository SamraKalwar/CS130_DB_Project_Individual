using Microsoft.AspNetCore.Mvc;
using WebApplication1.Data;
using WebApplication1.Models;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RentalController : ControllerBase
    {
        private readonly ResortDbContext _context;
        public RentalController(ResortDbContext context) => _context = context;

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Rental>>> Get() => await _context.Rentals.ToListAsync();

        [HttpPost]
        public async Task<ActionResult<Rental>> Post(Rental rental)
        {
            _context.Rentals.Add(rental);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = rental.RentalID }, rental);
        }
    }
}
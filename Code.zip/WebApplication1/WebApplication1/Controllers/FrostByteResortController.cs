using Microsoft.AspNetCore.Mvc;
using WebApplication1.Data;
using WebApplication1.Models;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FrostByteResortController : ControllerBase
    {
        private readonly ResortDbContext _context;
        public FrostByteResortController(ResortDbContext context) => _context = context;

        [HttpGet]
        public async Task<ActionResult<IEnumerable<FrostByteResort>>> Get() => await _context.FrostByteResorts.ToListAsync();

        [HttpPost]
        public async Task<ActionResult<FrostByteResort>> Post(FrostByteResort resort)
        {
            _context.FrostByteResorts.Add(resort);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = resort.ResortID }, resort);
        }
    }
}
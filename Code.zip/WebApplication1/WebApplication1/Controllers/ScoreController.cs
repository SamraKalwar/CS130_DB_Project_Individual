using Microsoft.AspNetCore.Mvc;
using WebApplication1.Data;
using WebApplication1.Models;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ScoreController : ControllerBase
    {
        private readonly ResortDbContext _context;
        public ScoreController(ResortDbContext context) => _context = context;

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Score>>> Get() => await _context.Scores.ToListAsync();

        [HttpPost]
        public async Task<ActionResult<Score>> Post(Score score)
        {
            _context.Scores.Add(score);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = score.ScoreID }, score);
        }
    }
}
namespace WebApplication1.Models
{
    public class Judge
    {
        public int JudgeID { get; set; }
        public string Name { get; set; }
        public int ExperienceYears { get; set; }
    }
}
namespace WebApplication1.Models
{
    public class SkatingSession
    {
        public int SessionID { get; set; }
        public int ResortID { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public int Capacity { get; set; }
        public string Status { get; set; }
    }
}
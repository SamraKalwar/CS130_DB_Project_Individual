namespace WebApplication1.Models
{
    public class Lesson
    {
        public int LessonID { get; set; }
        public int CoachID { get; set; }
        public int TouristID { get; set; }
        public DateTime LessonDate { get; set; }
        public int Duration { get; set; }
        public string Feedback { get; set; }
    }
}
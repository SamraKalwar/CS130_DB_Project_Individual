namespace WebApplication1.Models
{
    public class Coach
    {
        public int CoachID { get; set; }
        public string Name { get; set; }
        public string Specialization { get; set; }
        public decimal Rating { get; set; }
        public int ResortID { get; set; }
    }
}
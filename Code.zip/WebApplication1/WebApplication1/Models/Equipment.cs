namespace WebApplication1.Models
{
    public class Equipment
    {
        public int EquipmentID { get; set; }
        public int ResortID { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Condition { get; set; }
        public bool Availability { get; set; }
    }
}
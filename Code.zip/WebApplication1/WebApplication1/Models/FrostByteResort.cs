namespace WebApplication1.Models
{
    public class FrostByteResort
    {
        public int ResortID { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }
        public int Capacity { get; set; }
        public int EstablishedYear { get; set; }
    }
}
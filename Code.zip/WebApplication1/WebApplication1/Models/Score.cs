namespace WebApplication1.Models
{
    public class Score
    {
        public int ScoreID { get; set; }
        public int JudgeID { get; set; }
        public int ParticipantID { get; set; }
        public decimal ScoreValue { get; set; }
    }
}
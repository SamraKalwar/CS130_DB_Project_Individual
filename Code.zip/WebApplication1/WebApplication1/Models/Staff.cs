namespace WebApplication1.Models
{
    public class Staff
    {
        public int StaffID { get; set; }
        public string Name { get; set; }
        public string Role { get; set; }
        public DateTime HireDate { get; set; }
        public int ResortID { get; set; }
    }
}
namespace WebApplication1.Models
{
    public class Tourist
    {
        public int TouristID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Nationality { get; set; }
        public DateTime RegistrationDate { get; set; }
        public int ResortID { get; set; }
    }
}
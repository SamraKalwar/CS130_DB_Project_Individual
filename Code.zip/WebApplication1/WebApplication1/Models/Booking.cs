namespace WebApplication1.Models
{
    public class Booking
    {
        public int BookingID { get; set; }
        public int TouristID { get; set; }
        public int SessionID { get; set; }
        public DateTime BookingDate { get; set; }
        public string Type { get; set; }
        public string Status { get; set; }
    }
}
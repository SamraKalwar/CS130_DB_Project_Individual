namespace WebApplication1.Models
{
    public class Maintenance
    {
        public int MaintenanceID { get; set; }
        public int StaffID { get; set; }
        public int ResortID { get; set; }
        public string TaskDescription { get; set; }
        public DateTime Date { get; set; }
        public string Status { get; set; }
    }
}
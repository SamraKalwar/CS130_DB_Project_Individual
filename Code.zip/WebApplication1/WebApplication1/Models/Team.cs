namespace WebApplication1.Models
{
    public class Team
    {
        public int TeamID { get; set; }
        public string TeamName { get; set; }
        public int Year { get; set; }
    }
}
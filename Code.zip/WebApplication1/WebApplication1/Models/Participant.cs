namespace WebApplication1.Models
{
    public class Participant
    {
        public int ParticipantID { get; set; }
        public int TouristID { get; set; }
        public int CompetitionID { get; set; }
        public int TeamID { get; set; }
    }
}
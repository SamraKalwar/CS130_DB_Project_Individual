namespace WebApplication1.Models
{
    public class Rental
    {
        public int RentalID { get; set; }
        public int TouristID { get; set; }
        public int EquipmentID { get; set; }
        public DateTime RentalDate { get; set; }
        public DateTime ReturnDate { get; set; }
        public string Status { get; set; }
    }
}
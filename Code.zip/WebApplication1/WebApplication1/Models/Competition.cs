namespace WebApplication1.Models
{
    public class Competition
    {
        public int CompetitionID { get; set; }
        public string Name { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Category { get; set; }
        public int ResortID { get; set; }
    }
}
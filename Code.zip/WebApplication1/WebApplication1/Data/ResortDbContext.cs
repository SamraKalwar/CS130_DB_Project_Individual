using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1.Data
{
    public class ResortDbContext : DbContext
    {
        public ResortDbContext(DbContextOptions<ResortDbContext> options) : base(options) { }

        public DbSet<Tourist> Tourists { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<Equipment> Equipment { get; set; }
        public DbSet<Rental> Rentals { get; set; }
        public DbSet<Competition> Competitions { get; set; }
        public DbSet<Participant> Participants { get; set; }
        public DbSet<Score> Scores { get; set; }
        public DbSet<Staff> Staff { get; set; }
        public DbSet<Coach> Coaches { get; set; }
        public DbSet<Lesson> Lessons { get; set; }
        public DbSet<Team> Teams { get; set; }
        public DbSet<Judge> Judges { get; set; }
        public DbSet<SkatingSession> SkatingSessions { get; set; }
        public DbSet<Maintenance> Maintenance { get; set; }
        public DbSet<FrostByteResort> FrostByteResorts { get; set; }
    }
}
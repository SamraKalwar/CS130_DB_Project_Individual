CREATE TRIGGER trg_UpdateAvailabilityOnReturn
ON Rental
AFTER UPDATE
AS
BEGIN
    IF EXISTS (
        SELECT * FROM inserted i
        WHERE i.Status = 'Returned'
    )
    BEGIN
        UPDATE Equipment
        SET Availability = 'Y'
        WHERE EquipmentID IN (
            SELECT EquipmentID FROM inserted WHERE Status = 'Returned'
        );
    END
END;
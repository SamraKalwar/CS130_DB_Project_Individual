CREATE PROCEDURE GetLessonsByCoach
    @CoachID INT
AS
BEGIN
    SELECT L.LessonID, T.Name AS TouristName, L.LessonDate, L.Duration, L.Feedback
    FROM Lesson L
    JOIN Tourist T ON L.TouristID = T.TouristID
    WHERE L.CoachID = @CoachID;
END;
INSERT INTO Competition VALUES (3, 'Glacier Cup', '2025-07-01', '2025-07-04', 'Intermediate', 'Upcoming', 1);

SELECT Name, Status FROM Competition WHERE ResortID = 1;

UPDATE Competition SET Status = 'Ongoing' WHERE CompetitionID = 3;

DELETE FROM Competition WHERE CompetitionID = 3;
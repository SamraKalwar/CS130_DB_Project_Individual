INSERT INTO Rental VALUES (3, 1, 1, '2025-05-21', NULL, 'In Use');


SELECT * FROM Rental WHERE TouristID = 1;


UPDATE Rental SET ReturnDate = '2025-05-23', Status = 'Returned' WHERE RentalID = 3;

DELETE FROM Rental WHERE RentalID = 3;
INSERT INTO Participant VALUES (3, 1, 1, 1, 2);


SELECT * FROM Participant WHERE Rank = 1;


UPDATE Participant SET Rank = 1 WHERE ParticipantID = 3;


DELETE FROM Participant WHERE ParticipantID = 3;
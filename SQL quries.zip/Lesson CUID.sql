INSERT INTO Lesson VALUES (3, 1, 1, '2025-05-22', 30, 'Very helpful');

SELECT LessonDate, Feedback FROM Lesson WHERE CoachID = 1;

UPDATE Lesson SET Feedback = 'Excellent session' WHERE LessonID = 3;


DELETE FROM Lesson WHERE LessonID = 3;
INSERT INTO Score VALUES (3, 1, 1, 9.2);


SELECT * FROM Score WHERE JudgeID = 1;


UPDATE Score SET ScoreValue = 9.7 WHERE ScoreID = 3;


DELETE FROM Score WHERE ScoreID = 3;
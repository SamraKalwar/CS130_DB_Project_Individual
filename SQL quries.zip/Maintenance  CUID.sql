INSERT INTO Maintenance VALUES (3, 1, 1, 'Snow clearing', '2025-05-21', 'Scheduled');


SELECT * FROM Maintenance WHERE Status = 'Scheduled';


UPDATE Maintenance SET Status = 'Completed' WHERE MaintenanceID = 3;


DELETE FROM Maintenance WHERE MaintenanceID = 3;
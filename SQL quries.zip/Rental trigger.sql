CREATE TRIGGER trg_UpdateAvailabilityOnRental
ON Rental
AFTER INSERT
AS
BEGIN
    UPDATE Equipment
    SET Availability = 'N'
    WHERE EquipmentID IN (SELECT EquipmentID FROM inserted);
END;
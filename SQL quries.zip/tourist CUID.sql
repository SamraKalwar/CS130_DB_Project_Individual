
INSERT INTO Tourist VALUES (3, 'Charlie Ray', 'charlie@ice.com', '5551234567', 'Swiss', '2025-05-20', 1);


SELECT Name, Email FROM Tourist WHERE ResortID = 1;


UPDATE Tourist SET Phone = '1112223333' WHERE TouristID = 3;


DELETE FROM Tourist WHERE TouristID = 3;

INSERT INTO Staff VALUES (3, 'Laura Trent', 'Manager', '2024-02-01', 1);


SELECT * FROM Staff WHERE Role = 'Manager';

UPDATE Staff SET Role = 'Admin' WHERE StaffID = 3;


DELETE FROM Staff WHERE StaffID = 3;
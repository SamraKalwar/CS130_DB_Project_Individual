CREATE PROCEDURE GetAvailableEquipment
    @Type VARCHAR(50)
AS
BEGIN
    SELECT EquipmentID, Name, Condition
    FROM Equipment
    WHERE Type = @Type AND Availability = 'Y';
END;
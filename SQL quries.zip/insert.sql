
INSERT INTO FrostByteResort VALUES (1, 'Snowy Peaks Resort', 'Alberta, Canada', 200, 2005);
INSERT INTO FrostByteResort VALUES (2, 'IceGlide Resort', 'Aspen, USA', 150, 2010);


INSERT INTO Tourist VALUES (1, 'Alice Smith', 'alice@example.com', '1234567890', 'Canadian', '2024-12-01', 1);
INSERT INTO Tourist VALUES (2, 'Bob Johnson', 'bob@example.com', '9876543210', 'American', '2025-01-10', 2);


INSERT INTO Staff VALUES (1, 'Carol Davis', 'Technician', '2023-05-15', 1);
INSERT INTO Staff VALUES (2, 'David Lee', 'Receptionist', '2024-03-20', 2);


INSERT INTO Equipment VALUES (1, 'Helmet A', 'Helmet', 'Good', 'Y', 1);
INSERT INTO Equipment VALUES (2, 'Skates B', 'Skates', 'Excellent', 'Y', 2);


INSERT INTO Rental VALUES (1, 1, 1, '2025-05-01', '2025-05-03', 'Returned');
INSERT INTO Rental VALUES (2, 2, 2, '2025-05-02', NULL, 'In Use');


INSERT INTO SkatingSession VALUES (1, '2025-05-10 10:00:00', '2025-05-10 12:00:00', 30, 'Scheduled', 1);
INSERT INTO SkatingSession VALUES (2, '2025-05-11 15:00:00', '2025-05-11 17:00:00', 25, 'Scheduled', 2);

INSERT INTO Booking VALUES (1, 1, 1, '2025-05-05', 'Lesson', 'Confirmed');
INSERT INTO Booking VALUES (2, 2, 2, '2025-05-06', 'Session', 'Pending');


INSERT INTO Coach VALUES (1, 'Emma White', 'Figure Skating', 4.8, 1);
INSERT INTO Coach VALUES (2, 'Frank Black', 'Speed Skating', 4.5, 2);


INSERT INTO Lesson VALUES (1, 1, 1, '2025-05-07', 60, 'Great learning!');
INSERT INTO Lesson VALUES (2, 2, 2, '2025-05-08', 45, 'Good pace and tips');


INSERT INTO Competition VALUES (1, 'Winter Showdown', '2025-06-01', '2025-06-05', 'Advanced', 'Upcoming', 1);
INSERT INTO Competition VALUES (2, 'Ice Battle', '2025-06-10', '2025-06-12', 'Beginner', 'Upcoming', 2);


INSERT INTO Team VALUES (1, 'Ice Breakers', 2025);
INSERT INTO Team VALUES (2, 'Frost Fighters', 2025);


INSERT INTO Participant VALUES (1, 1, 1, 1, 1);
INSERT INTO Participant VALUES (2, 2, 2, 2, 2);


INSERT INTO Judge VALUES (1, 'George Miller', 10);
INSERT INTO Judge VALUES (2, 'Hannah Brown', 8);


INSERT INTO Score VALUES (1, 1, 1, 9.5);
INSERT INTO Score VALUES (2, 2, 2, 8.7);


INSERT INTO Maintenance VALUES (1, 1, 1, 'Repaired ice rink lights', '2025-05-01', 'Completed');
INSERT INTO Maintenance VALUES (2, 2, 2, 'Checked skate sharpening machine', '2025-05-02', 'In Progress');

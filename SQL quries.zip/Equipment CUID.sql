
INSERT INTO Equipment VALUES (3, 'Gloves A', 'Gloves', 'New', 'Y', 1);


SELECT * FROM Equipment WHERE Availability = 'Y';


UPDATE Equipment SET Availability = 'N' WHERE EquipmentID = 3;


DELETE FROM Equipment WHERE EquipmentID = 3;

CREATE PROCEDURE AssignLesson
    @CoachID INT,
    @TouristID INT,
    @LessonDate DATE,
    @Duration INT,
    @Feedback VARCHAR(500)
AS
BEGIN
    INSERT INTO Lesson (CoachID, TouristID, LessonDate, Duration, Feedback)
    VALUES (@CoachID, @TouristID, @LessonDate, @Duration, @Feedback);
END;